//Bowei Kou

#include <stdlib.h>
#include <stdio.h>

#include "structs.h"
#include "debug.h"

#include "memory.h"

//allocate the memory for object
struct Object* allocateOb(){
        static int ob_allocate = 0;
        struct Object* ob = malloc(sizeof(struct Object));
        if (ob == NULL){
                if(TEXT) printf("DIAGNOSTIC: Memory allocation failed.\n");
                return NULL;
        }
        ob_allocate++;
        if (TEXT) printf("DIAGNOSTIC: %d objects allocated.\n", ob_allocate);
        return ob;
}

//free the memory
void freeOb(struct Object *ob){
        static int ob_free = 0;
        if(ob !=NULL){
                free(ob);
                ob_free++;
                if(TEXT)printf("DIAGNOSTIC: %d objects freed.\n", ob_free);
        }
        else {
		if(TEXT)printf("DIAGNOSTIC: Accepts a NULL pointer.\n");
	}
}

