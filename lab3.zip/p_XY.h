/* Bowei Kou */

bool by_X(void *data1, void *data2);
bool by_Y(void *data1, void *data2);
int main();
