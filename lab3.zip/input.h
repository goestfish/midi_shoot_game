/* Bowei Kou */

void get_data(struct Sim* sim, unsigned short code, double x, double y, double direction);
bool good_input_run();
struct Sim* init_list();
