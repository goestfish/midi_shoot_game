/* Bowei Kou */

void data(struct Object* ob, double x, double y, double direction);
int main();
