/* Bowei Kou */

struct Object* allocateOb();
void freeOb(struct Object *ob);
int main();
