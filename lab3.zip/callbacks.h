/* Bowei Kou */

bool always_T(void *data, void*helper);
bool by_X(void *data1, void *data2);
bool by_Y(void *data1, void *data2);
bool by_color(void *data1, void *data2);
void clear_smile(void *data);
void delete_thing(void *data);
bool good_position(void *data, void*helper);
bool hit_smile(void *data, void*helper);
bool mustGo(void *data, void*helper);
void new_XY(void *thing);
void new_XY_S(void *thing);
void reflect(void *thing);
void rotation(void *thing);
void transfer_thing(void *data);
