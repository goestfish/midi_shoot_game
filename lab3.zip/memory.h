/* Bowei Kou */

struct Object* allocateOb();
void freeOb(struct Object *ob);
