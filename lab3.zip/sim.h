/* Bowei Kou */

void clear_lists(struct Sim *sim);
void run_sim(struct Sim *sim);
