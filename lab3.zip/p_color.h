/* Bowei Kou */

bool by_color(void *data1, void *data2);
int main();
