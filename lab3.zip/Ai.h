/* Bowei Kou */

void delete_Projectile(struct Sim *sim);
void delete_Smile(struct Sim *sim);
void fire(struct Object *ob, struct Sim *sim);
void update_Projectile(struct Sim *sim);
void update_Smile(struct Sim *sim);
