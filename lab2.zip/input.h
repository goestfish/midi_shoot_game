/* Bowei Kou */

bool master_input();
