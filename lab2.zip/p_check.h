/* Bowei Kou */

int getType(unsigned short code);
int isSmile(unsigned short code);
int main();
