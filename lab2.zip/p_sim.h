/* Bowei Kou */

double degreesToRadians(double degree);
bool isValidPosition(double x, double y);
int main();
void runSimulation(unsigned short code, double x, double y, double dir);
