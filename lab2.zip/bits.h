/* Bowei Kou */

int getChecksum(unsigned short code);
int getColor(unsigned short code);
int getSpeed (unsigned short code);
int getType(unsigned short code);
bool isProjectile(unsigned short code);
bool isSmile(unsigned short code);
bool isValid(unsigned short code);
