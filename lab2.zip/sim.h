/* Bowei Kou */

double degreesToRadians(double degree);
bool isValidPosition(double ball[], short unsigned code, double time);
void runSimulation(unsigned short code, double x, double y, double dir);
