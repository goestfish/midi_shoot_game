/* Bowei Kou */

void master_X(double time, unsigned short code, double ball[]);
void master_graphics(double et, unsigned short code, double ball[]);
void master_output(double et, unsigned short code, double ball[]);
void master_scanf(int words);
void master_text(double et, unsigned short code, double ball[]);
void master_touch_wall(double time, unsigned short code, double ball[]);
void master_wall_output(double time, unsigned short code, double ball[]);
