/* I AM GETTING A 0 ON THIS LAB */

double d_to_r(double degrees);
double r_to_d(double rads);
double rationalize(double degrees);
