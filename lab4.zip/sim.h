/* I AM GETTING A 0 ON THIS LAB */

void add_object(struct Sim *game, unsigned short code, double X, double Y, double direction);
void check_impacts(void *data);
void clear_lists(struct Sim *game);
double distance(struct Datum p1, struct Datum p2);
bool hits_wall(void *data, void * helper);
void move_shot(void *data);
struct Datum one_step(struct Datum current, int speed, double dt);
void projectile_dies( void *data);
void run_sim(struct Sim *game);
void smile_dies( void *data);
bool takes_impact(void *data, void *helper);
