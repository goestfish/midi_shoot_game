
/* Copyright 2023, Neil Kirby.  Not for disclosure without permission */

// put system shared libraries first - they are unlikely to have bugs.
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>


// put custom libraries next, also unlikely to have bugs.

// put our own header files next.
// Start with one that are #define and structs
#include "debug.h"
#include "structs.h"

// includes for header files based on our own C code goes here.
// Always include the header for the file itself -
// THis validates the header declarations against the defninitions.
// We are spoiled by our automatically generated headers, but we still
// validate them.  We put the include for this file dead last.

#include "bits.h"
#include "output.h"
#include "sim.h"

#include "input.h"

bool good_read(struct Sim *game, FILE* file)
{
	double X, Y, direction;
	unsigned short code;
	int tokens;

	while( 4 ==(tokens = 
		fscanf(file, "%hx %lf %lf %lf", &code, &X, &Y, &direction)))
	{
	    if(valid_code(code)) // really ought to validate ALL values
	    {
	    	add_object(game, code, X, Y, direction);
	    }
	    else
	    {
	    	output_bad_code(code);
		return(false);
	    }

	}
	output_scanf(tokens);
	return( tokens == EOF);

}

/* the lab 4 bonus code will have more input routines. */


