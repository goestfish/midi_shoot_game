/* I AM GETTING A 0 ON THIS LAB */

int main();
char* team(int color);
