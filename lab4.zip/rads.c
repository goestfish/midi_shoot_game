

/* copyright 2023 Neil Kirby */
#include <math.h>
#include "pi.h"

double r_to_d(double rads)
{
	return rads * 180.0 / M_PI;
}

double d_to_r(double degrees)
{
	return degrees * M_PI / 180.0;
}

double rationalize(double degrees)
{
	if( degrees >= 360.0)degrees -= 360;
	if(degrees < 0.0 ) degrees += 360.0;
	return degrees;
}

