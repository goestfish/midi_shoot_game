#include <stdio.h>

char* team(int color){
        char* name[]= {
                "Black",
                "Red",
                "Green",
                "Yellow",
                "Blue",
                "Magenta",
                "Cyan",
                "White"
        };
        return name[color];
}

int main(){
	for(int i=0;i<=7;i++){
		printf("%s\n",team(i));
}
	return 0;
}
