/* Bowei Kou */

int count(void *head, CriteriaFunction countThis, void *helper);
void iterate(void *head, ActionFunction doThis);
