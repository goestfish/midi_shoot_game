/* I AM GETTING A 0 ON THIS LAB */

void compute_reflections(double direction, double *alt1, double *alt2);
double d_to_r(double degrees);
int main();
double r_to_d(double rads);
double rationalize(double degrees);
