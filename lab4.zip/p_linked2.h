/* Bowei Kou */

int deleteSome(void *p2head, CriteriaFunction mustGo, void *helper, ActionFunction disposal, int text);
bool insert(void* p2head, void *data, ComparisonFunction goesInFrontOf, int text);
void sort(void *hptr, ComparisonFunction cf);
