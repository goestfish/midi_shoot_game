
/* copyright 2023 Neil Kirby, not for disclosure */

#include <stdio.h>

#include "linkedlist.h"
#include "structs.h"

#include "callbacks.h"

/* start with comparison functions needed by insert & sort */
bool by_X(void *data1, void *data2)
{
	struct Object *o1 = data1;
	struct Object *o2 = data2;

	return ( o1->current.X < o2->current.X);
}

bool by_color(void *data1, void *data2)
{
	struct Object *o1 = data1;
	struct Object *o2 = data2;

	return ( o1->color < o2->color);
}


/* criteria functions for delete, count */
bool always_true(void *data, void *helper)
{
	return true;
}

