/* I AM GETTING A 0 ON THIS LAB */

unsigned int get_color(unsigned short code);
unsigned int get_speed(unsigned short code);
bool is_projectile(unsigned short code);
bool is_smile(unsigned short code);
bool valid_code(unsigned short code);
