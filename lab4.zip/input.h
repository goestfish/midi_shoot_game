/* Bowei Kou */

bool good_read(struct Sim *game, FILE* file);
