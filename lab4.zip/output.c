

/* Copyright 2023, Neil Kirby.  Not for disclosure without permission */

// put system shared libraries first - they are unlikely to have bugs.
#include <stdio.h>
#include <stdlib.h>

#include "midi.h"
#include "linkedlist.h"
// put our own header files next.
// Start with one that are #define and structs
#include "debug.h"

#include "structs.h"


// includes for header files based on our own C code goes here.
// Always include the header for the file itself
// THis validates the header declarations against the defninitions.
// We are spoiled by our automatically generated headers, but we still
// validate them.  We put the include for this file dead last.
#include "n2.h"
#include "bits.h"
#include "callbacks.h"

#include "output.h"


/* static functionas are private code I don't want to expose outside the 
 * file.  They have to come first before they are use dor else I have to
 * forward declare them.  Hence a mostly upside down order with main entry
 * points at the bottom and the leaves at the top. */

/* at the very end, we need to show the scores */
static void show_scores(struct Sim *game)
{
	int i;
	for (i=1; i<=7; i++)
	{
	    midi_score(game->score[i], i);
	}
}

// get the team name
static char* team(int color){
	char* name[]= {
		"Black",
		"Red",
		"Green",
		"Yellow",
		"Blue",
		"Magenta",
		"Cyan",
		"White"
	};
	return name[color];
}

// projectiles and smiels print the same way 
static void print_object(void *data)
{
	struct Object *thing = data;

	printf("%7s %2d    %9.6lf, %9.6lf    %3.0lf\n",
		team(thing->color), thing->speed, thing->current.X, 
		thing->current.Y, thing->current.direction);
}

/* master print - somebody else checked that we are in TEXT mode, this si
 * used by regular output and at the end */
static void master_print(struct Sim *game)
{
	printf("\n%7s %2s    %9s, %9s    %3s    ET=%9.6lf\n",
	"Color", "Sp", "__X______", "__Y______", "_D_", game->elapsed);

	// smiles will stay in color order
	if(game->smile_list)
	{
	    printf("Smiles:\n");
	    iterate(game->smile_list, print_object);
	}
	// projectiles need to be forced back into X order
	// and only text output cares
	if(game->shot_list)
	{
	    printf("Projectiles:\n");
	    sort(game->shot_list, by_X);
	    iterate(game->shot_list, print_object);
	}
	if(game->hit_list)
	{
	    printf("Hits:\n");
	    iterate(game->hit_list, print_object);
	}

}

// they draw with a different call than smiles
static void draw_projectile(void *data)
{
	struct Object *thing = data;

	 midi_projectile( thing->color, 
	     thing->current.X, thing->current.Y, thing->current.direction);
}

// smiles need a score
static void draw_smile(void *data)
{
	struct Object *thing = data;

	 midi_smile( thing->game->score[thing->color], thing->color, 
	     thing->current.X, thing->current.Y, thing->current.direction);
}

// peer to master print, call by master output, I draw everything
static void master_draw(struct Sim *game)
{
	midi_clear();
	midi_time( (int) (game->elapsed * 1000) );

	// have to do this before we do smiles since they print on the same
	// line as a smile.  That way the smile overwrites the simple score
	// if we have a smile for that team on the board
	show_scores(game);

	// two lists of stuff, using different action functions
	iterate(game->smile_list, draw_smile);
	iterate(game->shot_list, draw_projectile);

	// final stuff to get those graphics out
	midi_refresh();
	microsleep( (unsigned int) ( game->delta_T * 1000000));

}

// Text mode - get the scroes out.
static void final_scores(struct Sim *game)
{
	int i;

	printf("\nFinal Scores:\n  Color   Score\n");
	
	for(i=1; i<= 7; i++)
	{
	    printf("%7s    %2d\n",team(i), game->score[i]);
	}

}

// what is printed at the end?
static void final_print(struct Sim *game)
{
	printf("\nFinal Output:\n");

	master_print(game);
	final_scores(game);
}

// draw the last stuff for 4 seconds
static void final_draw(struct Sim *game)
{
	double wait = 0.0;

	while( wait < 4.0) // just slightly magic
	{
	    master_draw(game);
	    wait += game->delta_T;
	}
}


/* PUBLIC ENTRY POINTS these are not static */

//I've been hit!
void hit_message(struct Object *thing, struct Object *shot)
{
        if(TEXT)printf("%s Smile at %9.6lf, %9.6lf gets hit by team %s!\n",
	    team(thing->color), thing->current.X, thing->current.Y, team(shot->color));
        if(GRAPHICS)midi_X(thing->color, thing->current.X, thing->current.Y);
}

// fire is pretty obvious in graphics mode, but we have to say so in text
// mode
void fire_message(struct Object *thing)
{
	if(TEXT)printf("%s Smile at %9.6lf, %9.6lf fires projectile\n",
	    team(thing->color), thing->current.X, thing->current.Y );
}

//likewise when proj hit the wall - text mnode message
void wall_message(struct Object *thing)
{
	if(TEXT)
	{
    printf("%s Projectile moving %d hits the wall at %9.6lf, %9.6lf\n", 
    team(thing->color), thing->speed, thing->current.X, thing->current.Y);
    	}
}

// bad bits!  Tell the world
void output_bad_code(unsigned short code)
{
	if(TEXT)printf("ERROR: input has bad code: hex %X\n", code);
}

// what did scanf finally end on?
void output_scanf(int tokens)
{
	if(TEXT)printf("scanf returned %d\n", tokens);
}

// THE typical entry point, output the world in normal play in every wya
// that we have.
void master_output(struct Sim *game)
{
	if(TEXT)master_print(game);
	if(GRAPHICS)master_draw(game);;
}

// At the end, do the output in all modes
void final_output(struct Sim *game)
{
	if(TEXT)final_print(game);
	if(GRAPHICS)final_draw(game);
}

