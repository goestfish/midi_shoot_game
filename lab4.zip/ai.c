

/* Copyright 2023, Neil Kirby.  Not for disclosure without permission */

// put system shared libraries first - they are unlikely to have bugs.
#include <stdio.h>
#include <stdlib.h>
#include <math.h>


// put custom libraries next, also unlikely to have bugs.
#include "midi.h"
#include "linkedlist.h"

// put our own header files next.
// Start with one that are #define and structs
#include "debug.h"
#include "structs.h"

// includes for header files based on our own C code goes here.
// Always include the header for the file itself -
// here in lab3.c we include lab3.h
// THis validates the header declarations against the defninitions.
// We are spoiled by our automatically generated headers, but we still
// validate them.  We put the include for this file dead last.

#include "sim.h"
#include "memory.h"
#include "callbacks.h"
#include "output.h"
#include "rads.h"

#include "ai.h"




static void compute_reflections(double direction, double *alt1, double *alt2)
{
	double theta = d_to_r(direction);
	double s = sin(theta);
	double c = cos(theta);

	double beta = atan2(-s, c);
	double gamma = atan2(s,-c);

	*alt1 = rationalize( r_to_d(beta));
	*alt2 = rationalize( r_to_d(gamma));
}


void fire(struct Object *thing)
{
	// fire a shot!
	struct Object *shot;

	fire_message(thing);
	if(shot = allocate_object())
	{
	    *shot = *thing; // copy all the data
	    // shots are twice as fast as we are
	    shot->speed *= 2;
	    if(!insert(&thing->game->shot_list, shot, by_X, TEXT))
	    {
		free_object(shot);
	    }
	}
}

void reflect_ai(struct Object *thing)
{
	struct Datum next;
	struct Datum *cp = &thing->current;

	next = one_step(thing->current, thing->speed, thing->game->delta_T);
	if( midi_touches_wall(next.X, next.Y))
	{
	    double r1, r2;
	    struct Datum proposed = thing->current;

	    compute_reflections(cp->direction, &r1, &r2);
	    // try the first reflection to see if it hits a wall
	    proposed.direction = r1;
	    next = one_step(proposed, thing->speed, thing->game->delta_T);
	    if( midi_touches_wall(next.X, next.Y))
	    {
	    	// must have been the wrong reflection, try the other
		proposed.direction = r2;
		next = one_step(proposed, thing->speed, thing->game->delta_T);
		if( midi_touches_wall(next.X, next.Y))
		{
		    // I must be in a corner, swap ends
		    proposed.direction = rationalize(cp->direction +180.0);
		}
	    }

if(DEBUG)printf("DEBUG: reflect_ai: %d at %5.2lf, %5.2lf facing %3.0lf turns to %.0lf\n", thing->color, cp->X, cp->Y, cp->direction, proposed.direction);

	    cp->direction = proposed.direction;
	    // having changed course, we shoot
	    fire(thing);
	}
	else
	{
if(DEBUG)printf("DEBUG: reflect_ai: %d at %5.2lf, %5.2lf facing %3.0lf steps\n", thing->color, cp->X, cp->Y, cp->direction );

	    thing->current = next;
	}
}


void default_ai(void * data)
{
	struct Object *thing = data;
	struct Datum next;
	struct Datum *cp = &thing->current;

	// this is the entry point for many different AI.
	// what follows is the default
	next = one_step(thing->current, thing->speed, thing->game->delta_T);
	if( midi_touches_wall(next.X, next.Y))
	{
	    double turn = 10.0;

	    if (thing->color & 1)turn = -10.0;

if(DEBUG)printf("DEBUG: default_ai: %d at %5.2lf, %5.2lf facing %3.0lf turns by %.0lf\n", thing->color, cp->X, cp->Y, cp->direction, turn);

	    cp->direction = rationalize( cp->direction + turn);
	    if( ( (int) cp->direction) %90 == 0)fire(thing);
	}
	else
	{
if(DEBUG)printf("DEBUG: default_ai: %d at %5.2lf, %5.2lf facing %3.0lf steps\n", thing->color, cp->X, cp->Y, cp->direction );

	    thing->current = next;
	}
}


void even_seconds(struct Object *thing)
{
	struct Datum next;

	// we shoot on even seconds, otherwise manuever 
	// with snap turns
	next = one_step(thing->current, thing->speed, thing->game->delta_T);
	if( midi_touches_wall(next.X, next.Y))
	{
		double turn = 90.0;
		if (thing->color & 1)turn = -90.0;
		//TODO: message goes here.
		thing->current.direction += turn;
	}
	else
	{
	    thing->current = next;
	}
	int i_et = thing->game->elapsed;
	if (i_et == thing->game->elapsed)fire(thing);
}

/* BONUS: do_ai */
void bonus_ai(void * data)
{
	struct Object *thing = data;

	reflect_ai(thing);
}

