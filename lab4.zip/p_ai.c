
/* copyright 2023 Neil Kirby */
#include <math.h>
#include <stdio.h>
#include "pi.h"

double r_to_d(double rads)
{
	return rads * 180.0 / M_PI;
}

double d_to_r(double degrees)
{
	return degrees * M_PI / 180.0;
}

double rationalize(double degrees)
{
	if( degrees >= 360.0)degrees -= 360;
	if(degrees < 0.0 ) degrees += 360.0;
	return degrees;
}

void compute_reflections(double direction, double *alt1, double *alt2)
{
	double theta = d_to_r(direction);
	double s = sin(theta);
	double c = cos(theta);

	double beta = atan2(-s, c);
	double gamma = atan2(s,-c);

	*alt1 = rationalize( r_to_d(beta));
	*alt2 = rationalize( r_to_d(gamma));
}

int main()
{
	double angle = 15.0, r1, r2;


	printf("Angle = %lf \n", angle);
	compute_reflections(angle, &r1, &r2);
	// now flip the sign of either and get an agnle back out
	printf("%lf yields %lf and %lf\n", angle, r1, r2);

	return 0;
}
