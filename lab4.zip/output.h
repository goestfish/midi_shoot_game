/* I AM GETTING A 0 ON THIS LAB */

void final_output(struct Sim *game);
void fire_message(struct Object *thing);
void hit_message(struct Object *thing, struct Object *shot);
void master_output(struct Sim *game);
void output_bad_code(unsigned short code);
void output_scanf(int tokens);
void wall_message(struct Object *thing);
