/* I AM GETTING A 0 ON THIS LAB */

bool good_input_run();
bool init();
int main();
void teardown();
