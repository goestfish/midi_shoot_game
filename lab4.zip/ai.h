/* I AM GETTING A 0 ON THIS LAB */

void bonus_ai(void * data);
void default_ai(void * data);
void even_seconds(struct Object *thing);
void fire(struct Object *thing);
void reflect_ai(struct Object *thing);
