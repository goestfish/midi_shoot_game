/* I AM GETTING A 0 ON THIS LAB */

struct Object *allocate_object();
void free_object(void *data);
