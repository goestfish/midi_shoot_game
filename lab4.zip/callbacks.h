/* I AM GETTING A 0 ON THIS LAB */

bool always_true(void *data, void *helper);
bool by_X(void *data1, void *data2);
bool by_color(void *data1, void *data2);
