
/* Copyright 2023, Neil Kirby.  Not for disclosure without permission */

// put system shared libraries first - they are unlikely to have bugs.
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <math.h>


// put custom libraries next, also unlikely to have bugs.
#include "linkedlist.h"
#include "midi.h"

// put our own header files next.
// Start with one that are #define and structs
#include "debug.h"
#include "structs.h"

// includes for header files based on our own C code goes here.
// Always include the header for the file itself -
// THis validates the header declarations against the defninitions.
// We are spoiled by our automatically generated headers, but we still
// validate them.  We put the include for this file dead last.
#include "bits.h"
#include "memory.h"
#include "callbacks.h"
#include "output.h"
#include "ai.h"
#include "input.h"
#include "rads.h"

#include "sim.h"

// forward declarations of static functions that won't be in my header

void clear_lists(struct Sim *game)
{
	int i;

    i = deleteSome(&game->smile_list, always_true, NULL, free_object, TEXT);
    if(DEBUG)printf("DEBUG: sim.c: clear_lists: %d smiles deleted\n", i);

    i = deleteSome(&game->shot_list, always_true, NULL, free_object, TEXT);
    if(DEBUG)printf("DEBUG: sim.c: clear_lists: %d shots deleted\n", i);

    i = deleteSome(&game->hit_list, always_true, NULL, free_object, TEXT);
    if(DEBUG)printf("DEBUG: sim.c: clear_lists: %d hits deleted\n", i);

}

static bool add_projectile(struct Sim *game, struct Object *thing)
{
	if(DEBUG)printf("sim.c: add_projectile:\n");
	bool rval = insert( &game->shot_list , thing, by_X, TEXT);
	if(DEBUG)printf("sim.c: projectile added.\n");
	return rval;
}

static bool add_smile(struct Sim *game, struct Object *thing)
{
	if(DEBUG)printf("sim.c: add_smile:\n");
	bool rval = insert( &game->smile_list , thing, by_color, TEXT);
	if(DEBUG)printf("sim.c: smile added.\n");
	if(rval)fire(thing);
	return rval;

}

static void load_thing(struct Object *thing, struct Sim *game, unsigned short code, double X, double Y, double direction)
{
	thing->color = get_color(code);
	thing->speed = get_speed(code);
	thing->desired = direction;
	thing->current.X = X;
	thing->current.Y = Y;
	thing->current.direction = direction;

	thing->game = game;
}

void add_object(struct Sim *game, unsigned short code, double X, double Y, double direction)
{
	bool on_list = false;
	/* allocate space and if that works,
	 * plug in the read values,
	 * pick a call to see if it inserts,
	 * recover memory if it did not */
	struct Object *thing;
	
	thing= allocate_object();
	if(thing)
	{
	    load_thing(thing, game, code, X, Y, direction);

	    if(is_projectile(code)) on_list = add_projectile(game, thing);
	    if(is_smile(code)) on_list = add_smile(game, thing);
	    /* we are silent about type we don't understand*/

	    /* recover memory here if it didn't insert*/
	}
}

bool hits_wall(void *data, void * helper)
{
	struct Object *thing = data;

	return midi_touches_wall(thing->current.X, thing->current.Y);
}

void projectile_dies( void *data)
{
	struct Object *thing = data;
	
	wall_message(thing);
	free_object(thing);

}

void smile_dies( void *data)
{
	struct Object *thing = data;
	
	if(!insert(&thing->game->hit_list, thing, by_color, TEXT))
	{
	    free_object(thing);
	}


}
static void purge_shots(struct Sim *game)
{
	deleteSome(&game->shot_list, hits_wall, NULL, projectile_dies, TEXT);
}

double distance(struct Datum p1, struct Datum p2)
{
	// yes it's call by value.
	double dx = p1.X - p2.X;
	double dy = p1.Y - p2.Y;

	return sqrt( (dx * dx) + (dy*dy));
}

bool takes_impact(void *data, void *helper)
{
	struct Object *smile = data;
	struct Object *shot = helper;

	// are they on different teams and are they close?
	if( distance(smile->current, shot->current) < 1.0)
	{
	    if(DEBUG)printf("Shot is close to smile.\n");
	    if (shot->color != smile->color)
	    {
	        // I don't like this side effect here, but it's the only 
		// place I have both objects in hand
	    	shot->game->score[shot->color]++;
		// not as problematic for output, but this is the only
		// place with both.
		hit_message(smile, shot);
		// return the value we came here to determine.
		return true;
	    }
	}
	return false;

}

void check_impacts(void *data)
{
	struct Object *thing = data;

	// we'd better be running this only the shot list or we could be
	// well and truly messed up.  Search the smile list for things this
	// shot hits
	
	deleteSome(&thing->game->smile_list, takes_impact, thing, smile_dies, TEXT);
}

static void purge_smiles(struct Sim *game)
{
	iterate(game->shot_list, check_impacts);
}

static void purge(struct Sim *game)
{
	/* did any shots hit the wall? */
	purge_shots(game);
	/* did any of the smiles get hit by enemy shot? */
	purge_smiles(game);
}

struct Datum one_step(struct Datum current, int speed, double dt)
{
	struct Datum result = current;

    result.X = current.X + speed * dt * sin(d_to_r(current.direction ));
    result.Y = current.Y + speed * dt * cos(d_to_r(current.direction ));
    	return result;
}

void move_shot(void *data)
{
	struct Object *thing = data;

thing->current = one_step(thing->current, thing->speed, thing->game->delta_T);
}


static void update(struct Sim *game)
{
	/* move the shots */
	iterate(game->shot_list, move_shot);
	/* smiles act
	 * In lab 3, different AI, in lab 4 user input */
	if(game->bonus)iterate(game->smile_list, bonus_ai);
	else iterate(game->smile_list, default_ai);
}

static bool game_on(struct Sim *game)
{
	/* put a time limit on it */
	if(game->elapsed >= 20.0)return false; /* magic number */

	/* if there are 2 or more smiles, keep palying */
	if(count(game->smile_list, always_true, NULL) <= 1) return false;

	return true;
}

void run_sim(struct Sim *game)
{
	if(DEBUG)printf("sim.c: run_sim::\n");

	while(game_on(game))
	{
	    master_output(game);
	    /* now we move foreard in time and space */
	    game->elapsed += game->delta_T;
	    update(game);
	    purge(game);
	}
}


