#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>

#include "node.h"
#include "linkedlist.h"

#include "p_linked1.h"


void iterate(void *head, ActionFunction doThis){
	Node *node = head;
	while(node!=NULL){
		doThis(node->data);
		node = node->next;
	}
	
}

int count(void *head, CriteriaFunction countThis, void *helper){
	Node *node = head;
	int num=0;
	while(node != NULL){
		if(countThis(node->data, helper))num++;
		node = node->next;
	}
	return num;
}
