

/* Copyright 2023, Neil Kirby.  Not for disclosure without permission */

// put system shared libraries first - they are unlikely to have bugs.
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// put custom libraries next, also unlikely to have bugs.
#include "midi.h"

// put our own header files next.
// Start with one that are #define and structs
#include "debug.h"
#include "structs.h"

// includes for header files based on our own C code goes here.
// Always include the header for the file itself -
// here in lab3.c we include lab3.h
// THis validates the header declarations against the defninitions.
// We are spoiled by our automatically generated headers, but we still
// validate them.  We put the include for this file dead last.
#include "n2.h"

#include "input.h"
#include "sim.h"
#include "output.h"

#include "lab4.h"

#define RVAL_BAD_INIT (1)
#define RVAL_BAD_INPUT (2)


/* I own all inits.  In future labs, I might morph to master init and call
 * my init minions to do the various subtasks.  For now, I'm simple enough
 * to do it all easily myself.  I shield main for all details about
 * initializations */
bool init()
{
	/* we might take manual control over what we feed midi_init
	 * SO that we turn it off but still debug our code. */
	return(TEXT || ( GRAPHICS && midi_initialize(false)));

}

/* Put all of the toys away.  In future labs I will own more stuff and
 * call my minions to do those things. */
void teardown()
{
	if(GRAPHICS)midi_teardown();
}

// This function checks if the argc is valid and print error message
bool check(int argc, char **argv){
	bool result = true;
	if(argc<2){
		printf("ERROR: insufficient args - no filename given\n");
		result = false;
	} else if(argc ==3){
		if((strcmp(argv[2],"bonus")!=0)||TEXT){
			printf("ERROR: Bonus code is not present.\n");
			result = false;
		}
	}
	return result;
}

// This function open the file and check if the fopen works correctly
FILE *open_file(int argc, char **argv, struct Sim *game){
	FILE *file=fopen(argv[1],"r");
	if(argc==2){
		if(file){
			if(TEXT)printf("DIAGNOSTIC: Successfully opend %s for reading.\n", argv[1]);
		}else{
			printf("ERROR: Unable to open %s for reading.\n", argv[1]);
		}
	}else if(argc==3){
		if(file){
			printf("Bonus mode enabled");
			game->bonus = true;
		}else{
			printf("ERROR: Unable to open %s for reading.\n", argv[1]);
		}
	}
	return file;
}

// This function will close the file and print message
void close_file(FILE *file){
	fclose(file);
	if(TEXT)printf("DIAGNOSTIC: Input file closed.\n");
}

// Check if this input is good
bool good_input_run(FILE *file, int argc, char **argv)
{
	bool rval = true;
	struct Sim maze = { 0.0, (1.0/32.0), 
			{0, 0, 0, 0, 0, 0, 0, 0}, false,
			NULL, NULL, NULL};
	struct Sim *game = &maze;

	file = open_file(argc, argv, game);
	if(file&&good_read(game, file))
	{
	    run_sim(game);
	    final_output(game);
	}
	else
	{
	    rval = false;
	}
	if(file)close_file(file);
	clear_lists(game);
	return rval;
}


/* Avoid details and call upon my minions to make it everything happen.  I own
 * those highest level things that I must own: performance timing and the
 * value we return to linux */
int main(int argc, char **argv)
{
	int rval = EXIT_SUCCESS;
	double start, runtime;
	FILE *file=stdin;

	start = now();	// this is the very first executable statement

	if(check(argc,argv)&&init())
	{
		if( !good_input_run(file, argc, argv)) rval = RVAL_BAD_INPUT;
	    	teardown();
	}
	else
	{
	    rval = RVAL_BAD_INIT;	// non zero, indicates an error
	}
	
	/* at this point we are done, graphics has been torn down*/
	printf("Returning %d\n", rval);
	runtime = now() - start;
	/* after graphics has been torn down, we can freely print */
	printf("Total runtime is %.9lf seconds\n", runtime);

	return rval;
}

