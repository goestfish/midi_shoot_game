/* Bowei Kou */

bool good_input_run();
bool init();
int main(int argc, char **argv);
void teardown();
