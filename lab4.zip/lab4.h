/* Bowei Kou */

bool check(int argc, char **argv);
void close_file(FILE *file);
bool good_input_run(FILE *file, int argc, char **argv);
bool init();
int main(int argc, char **argv);
FILE *open_file(int argc, char **argv, struct Sim *game);
void teardown();
